package com.example.telacadastro;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class PaginaCadastroActivity extends AppCompatActivity {

    // Declare os elementos do layout
    private ImageView imageView3;
    private TextView textView4;
    private TextView textView7;
    private EditText Edt_user1;
    private EditText Edt_user2;
    private EditText Edt_user3;
    private EditText Edt_user4;
    private EditText Edt_user5;
    private Button Btn_Terminar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagina_de_cadastro); // Substitua 'seu_layout_de_cadastro' pelo nome real do seu layout XML

        // Inicialize os elementos do layout
        imageView3 = findViewById(R.id.imageView3);
        textView4 = findViewById(R.id.textView4);
        textView7 = findViewById(R.id.textView7);
        Edt_user1 = findViewById(R.id.Edt_user1);
        Edt_user2 = findViewById(R.id.Edt_user2);
        Edt_user3 = findViewById(R.id.Edt_user3);
        Edt_user4 = findViewById(R.id.Edt_user4);
        Edt_user5 = findViewById(R.id.Edt_user5);
        Btn_Terminar = findViewById(R.id.Btn_Terminar);

        // Configurar um ouvinte de clique para o botão "Terminar"
        Btn_Terminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Adicione a lógica para o botão "Terminar" aqui
                // Por exemplo, pode validar os campos e enviar os dados para o servidor

                // Adicione a lógica adicional conforme necessário
            }
        });
    }
}
