import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class paginaLoguin extends AppCompatActivity {

    // Declare os elementos do layout
    private EditText edtUser;
    private EditText edtPassword;
    private Button btnLogin;
    private TextView txtNomeDoApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.seu_layout); // Substitua 'seu_layout' pelo nome real do seu layout XML

        // Inicialize os elementos do layout
        edtUser = findViewById(R.id.edt_user2);
        edtPassword = findViewById(R.id.edt_password);
        btnLogin = findViewById(R.id.btn_login);
        txtNomeDoApp = findViewById(R.id.Txt_nomeDoApp);

        // Configurar um ouvinte de clique para o botão
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Obter o texto dos EditTexts
                String username = edtUser.getText().toString();
                String password = edtPassword.getText().toString();

                // Exibir o nome do aplicativo e os detalhes de login no TextView
                String mensagem = "Bem-vindo ao " + txtNomeDoApp.getText() +
                        "\nNome de usuário: " + username +
                        "\nSenha: " + password;
                txtNomeDoApp.setText(mensagem);
            }
        });
    }
}
