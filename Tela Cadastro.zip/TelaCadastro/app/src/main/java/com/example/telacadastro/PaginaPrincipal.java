package com.example.telacadastro;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class PaginaPrincipal extends AppCompatActivity {

    private ImageView imageView;
    private TextView textView;
    private TextView textView2;
    private Button button;
    private TextView textView6;
    private Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagina_principal);

        imageView = findViewById(R.id.imageView);
        textView = findViewById(R.id.textView);
        textView2 = findViewById(R.id.textView2);
        button = findViewById(R.id.button);
        textView6 = findViewById(R.id.textView6);
        button2 = findViewById(R.id.button2);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Adicione a lógica para o botão de login aqui
                // Por exemplo, pode abrir a tela de login

                // Adicionar a lógica para navegar para a tela de login
                Intent intent = new Intent(PaginaPrincipal.this, paginaLoguin.class);
                startActivity(intent);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Adicione a lógica para o botão de cadastro aqui
                // Por exemplo, pode abrir a tela de cadastro

                // Adicionar a lógica para navegar para a tela de cadastro
                Intent intent = new Intent(PaginaPrincipal.this, PaginaCadastroActivity.class);
                startActivity(intent);
            }
        });
    }
}
