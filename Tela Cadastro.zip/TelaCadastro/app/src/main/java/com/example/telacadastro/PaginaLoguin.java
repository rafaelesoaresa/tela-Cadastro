package com.example.telacadastro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PaginaLoguin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagina_loguin);
    }
}